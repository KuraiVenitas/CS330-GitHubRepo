///////////////////////////////////////////////////////////////////////////////
// scenemanager.cpp
// ============
// manage the preparing and rendering of 3D scenes - textures, materials, lighting
//
//  AUTHOR: Brian Battersby - SNHU Instructor / Computer Science
//	Created for CS-330-Computational Graphics and Visualization, Nov. 1st, 2023
///////////////////////////////////////////////////////////////////////////////

#include "SceneManager.h"

#ifndef STB_IMAGE_IMPLEMENTATION
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"
#endif

#include <glm/gtx/transform.hpp>

// declaration of global variables
namespace
{
	const char* g_ModelName = "model";
	const char* g_ColorValueName = "objectColor";
	const char* g_TextureValueName = "objectTexture";
	const char* g_UseTextureName = "bUseTexture";
	const char* g_UseLightingName = "bUseLighting";
	const char* g_UseTextureOverlayName = "bUseTextureOverlay"; // used to simplify texture overlay
	const char* g_TextureOverlayValueName = "overlayTexture"; // used to simplify texture overlay
}

/***********************************************************
 *  SceneManager()
 *
 *  The constructor for the class
 ***********************************************************/
SceneManager::SceneManager(ShaderManager *pShaderManager)
{
	m_pShaderManager = pShaderManager;
	m_basicMeshes = new ShapeMeshes();
}

/***********************************************************
 *  ~SceneManager()
 *
 *  The destructor for the class
 ***********************************************************/
SceneManager::~SceneManager()
{
	m_pShaderManager = NULL;
	delete m_basicMeshes;
	m_basicMeshes = NULL;
}

/***********************************************************
 *  CreateGLTexture()
 *
 *  This method is used for loading textures from image files,
 *  configuring the texture mapping parameters in OpenGL,
 *  generating the mipmaps, and loading the read texture into
 *  the next available texture slot in memory.
 ***********************************************************/
bool SceneManager::CreateGLTexture(const char* filename, std::string tag)
{
	int width = 0;
	int height = 0;
	int colorChannels = 0;
	GLuint textureID = 0;

	// indicate to always flip images vertically when loaded
	stbi_set_flip_vertically_on_load(true);

	// try to parse the image data from the specified image file
	unsigned char* image = stbi_load(
		filename,
		&width,
		&height,
		&colorChannels,
		0);

	// if the image was successfully read from the image file
	if (image)
	{
		std::cout << "Successfully loaded image:" << filename << ", width:" << width << ", height:" << height << ", channels:" << colorChannels << std::endl;

		glGenTextures(1, &textureID);
		glBindTexture(GL_TEXTURE_2D, textureID);

		// set the texture wrapping parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
		// set texture filtering parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

		// if the loaded image is in RGB format
		if (colorChannels == 3)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB8, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image);
		// if the loaded image is in RGBA format - it supports transparency
		else if (colorChannels == 4)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, image);
		else
		{
			std::cout << "Not implemented to handle image with " << colorChannels << " channels" << std::endl;
			return false;
		}

		// generate the texture mipmaps for mapping textures to lower resolutions
		glGenerateMipmap(GL_TEXTURE_2D);

		// free the image data from local memory
		stbi_image_free(image);
		glBindTexture(GL_TEXTURE_2D, 0); // Unbind the texture

		// register the loaded texture and associate it with the special tag string
		m_textureIDs[m_loadedTextures].ID = textureID;
		m_textureIDs[m_loadedTextures].tag = tag;
		m_loadedTextures++;

		return true;
	}

	std::cout << "Could not load image:" << filename << std::endl;

	// Error loading the image
	return false;
}

/***********************************************************
 *  BindGLTextures()
 *
 *  This method is used for binding the loaded textures to
 *  OpenGL texture memory slots.  There are up to 16 slots.
 ***********************************************************/
void SceneManager::BindGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		// bind textures on corresponding texture units
		glActiveTexture(GL_TEXTURE0 + i);
		glBindTexture(GL_TEXTURE_2D, m_textureIDs[i].ID);
	}
}

/***********************************************************
 *  DestroyGLTextures()
 *
 *  This method is used for freeing the memory in all the
 *  used texture memory slots.
 ***********************************************************/
void SceneManager::DestroyGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		glGenTextures(1, &m_textureIDs[i].ID);
	}
}

/***********************************************************
 *  FindTextureID()
 *
 *  This method is used for getting an ID for the previously
 *  loaded texture bitmap associated with the passed in tag.
 ***********************************************************/
int SceneManager::FindTextureID(std::string tag)
{
	int textureID = -1;
	int index = 0;
	bool bFound = false;

	while ((index < m_loadedTextures) && (bFound == false))
	{
		if (m_textureIDs[index].tag.compare(tag) == 0)
		{
			textureID = m_textureIDs[index].ID;
			bFound = true;
		}
		else
			index++;
	}

	return(textureID);
}

/***********************************************************
 *  FindTextureSlot()
 *
 *  This method is used for getting a slot index for the previously
 *  loaded texture bitmap associated with the passed in tag.
 ***********************************************************/
int SceneManager::FindTextureSlot(std::string tag)
{
	int textureSlot = -1;
	int index = 0;
	bool bFound = false;

	while ((index < m_loadedTextures) && (bFound == false))
	{
		if (m_textureIDs[index].tag.compare(tag) == 0)
		{
			textureSlot = index;
			bFound = true;
		}
		else
			index++;
	}

	return(textureSlot);
}

/***********************************************************
 *  FindMaterial()
 *
 *  This method is used for getting a material from the previously
 *  defined materials list that is associated with the passed in tag.
 ***********************************************************/
bool SceneManager::FindMaterial(std::string tag, OBJECT_MATERIAL& material)
{
	if (m_objectMaterials.size() == 0)
	{
		return(false);
	}

	int index = 0;
	bool bFound = false;
	while ((index < m_objectMaterials.size()) && (bFound == false))
	{
		if (m_objectMaterials[index].tag.compare(tag) == 0)
		{
			bFound = true;
			material.diffuseColor = m_objectMaterials[index].diffuseColor;
			material.specularColor = m_objectMaterials[index].specularColor;
			material.shininess = m_objectMaterials[index].shininess;
		}
		else
		{
			index++;
		}
	}

	return(true);
}

/***********************************************************
 *  SetTransformations()
 *
 *  This method is used for setting the transform buffer
 *  using the passed in transformation values.
 ***********************************************************/
void SceneManager::SetTransformations(
	glm::vec3 scaleXYZ,
	float XrotationDegrees,
	float YrotationDegrees,
	float ZrotationDegrees,
	glm::vec3 positionXYZ)
{
	// variables for this method
	glm::mat4 modelView;
	glm::mat4 scale;
	glm::mat4 rotationX;
	glm::mat4 rotationY;
	glm::mat4 rotationZ;
	glm::mat4 translation;

	// set the scale value in the transform buffer
	scale = glm::scale(scaleXYZ);
	// set the rotation values in the transform buffer
	rotationX = glm::rotate(glm::radians(XrotationDegrees), glm::vec3(1.0f, 0.0f, 0.0f));
	rotationY = glm::rotate(glm::radians(YrotationDegrees), glm::vec3(0.0f, 1.0f, 0.0f));
	rotationZ = glm::rotate(glm::radians(ZrotationDegrees), glm::vec3(0.0f, 0.0f, 1.0f));
	// set the translation value in the transform buffer
	translation = glm::translate(positionXYZ);

	modelView = translation * rotationZ * rotationY * rotationX * scale;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setMat4Value(g_ModelName, modelView);
	}
}

/***********************************************************
 *  SetShaderColor()
 *
 *  This method is used for setting the passed in color
 *  into the shader for the next draw command
 ***********************************************************/
void SceneManager::SetShaderColor(
	float redColorValue,
	float greenColorValue,
	float blueColorValue,
	float alphaValue)
{
	// variables for this method
	glm::vec4 currentColor;

	currentColor.r = redColorValue;
	currentColor.g = greenColorValue;
	currentColor.b = blueColorValue;
	currentColor.a = alphaValue;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setIntValue(g_UseTextureName, false);
		m_pShaderManager->setVec4Value(g_ColorValueName, currentColor);
	}
}

/***********************************************************
 *  SetShaderTexture()
 *
 *  This method is used for setting the texture data
 *  associated with the passed in ID into the shader.
 ***********************************************************/
void SceneManager::SetShaderTexture(
	std::string textureTag)
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setIntValue(g_UseTextureName, true);

		int textureID = -1;
		textureID = FindTextureSlot(textureTag);
		m_pShaderManager->setSampler2DValue(g_TextureValueName, textureID);
	}
}

/***********************************************************
 *  SetTextureUVScale()
 *
 *  This method is used for setting the texture UV scale
 *  values into the shader.
 ***********************************************************/
void SceneManager::SetTextureUVScale(float u, float v)
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setVec2Value("UVscale", glm::vec2(u, v));
	}
}

/***********************************************************
 *  SetShaderMaterial()
 *
 *  This method is used for passing the material values
 *  into the shader.
 ***********************************************************/
void SceneManager::SetShaderMaterial(
	std::string materialTag)
{
	if (m_objectMaterials.size() > 0)
	{
		OBJECT_MATERIAL material;
		bool bReturn = false;

		bReturn = FindMaterial(materialTag, material);
		if (bReturn == true)
		{
			m_pShaderManager->setVec3Value("material.diffuseColor", material.diffuseColor);
			m_pShaderManager->setVec3Value("material.specularColor", material.specularColor);
			m_pShaderManager->setFloatValue("material.shininess", material.shininess);
		}
	}
}

/**************************************************************/
/*** STUDENTS CAN MODIFY the code in the methods BELOW for  ***/
/*** preparing and rendering their own 3D replicated scenes.***/
/*** Please refer to the code in the OpenGL sample project  ***/
/*** for assistance.                                        ***/
/**************************************************************/



/**************************************************************************************************************************************************************************************/


/***********************************************************
 *  SetTextureShaderOverlay()
 *
 *  This method is used for overlaying textures
 ***********************************************************/
void SceneManager::SetupSceneLights() {

	m_pShaderManager->setBoolValue(g_UseLightingName, true); // Allows the custom lighting to take effect
	
	// Directional Lighting provides some dim general lighting
	m_pShaderManager->setVec3Value("directionalLight.direction", 0.0f, -1.0f, 1.0f);
	m_pShaderManager->setVec3Value("directionalLight.ambient", .5f, .5f, .5f); 
	m_pShaderManager->setVec3Value("directionalLight.diffuse", 1.0f, 1.0f, 1.0f); // Diffuses/brightens red slightly more than other colors
	m_pShaderManager->setVec3Value("directionalLight.specular", 0.5f, 0.5f, 0.5f); // Equal shine on all objects, white-shine
	m_pShaderManager->setBoolValue("directionalLight.bActive", true); // Turns the light on in a sense

	// Point light provides a slight blue tint to the scene and brightens it up a bit
	m_pShaderManager->setVec3Value("pointLights[0].position", -10.0f, 8.0f, 5.0f);
	m_pShaderManager->setVec3Value("pointLights[0].ambient", 0.4f, 0.4f, 0.5f);
	m_pShaderManager->setVec3Value("pointLights[0].diffuse", 0.3f, 0.3f, 0.3f);
	m_pShaderManager->setVec3Value("pointLights[0].specular", 0.1f, 0.1f, 0.1f);
	m_pShaderManager->setBoolValue("pointLights[0].bActive", true);
}
void SceneManager::SetShaderTextureOverlay(	std::string textureTag)
{
	if (NULL != m_pShaderManager)
	{
		if (textureTag.size() > 0)
		{
			m_pShaderManager->setIntValue(g_UseTextureOverlayName, true);

			int textureID = -1;
			textureID = FindTextureSlot(textureTag);
			m_pShaderManager->setSampler2DValue(g_TextureOverlayValueName, textureID);
		}
		else
		{
			m_pShaderManager->setIntValue(g_UseTextureOverlayName, false);
		}
	}
}
void SceneManager::DefineObjectMaterials() {

	// Object materials used for the scene objects
	OBJECT_MATERIAL glossySurface;
	glossySurface.diffuseColor = glm::vec3(0.8f, 0.8f, 0.8f);  
	glossySurface.specularColor = glm::vec3(1.0f, 1.0f, 1.0f);  
	glossySurface.shininess = 128.0f;
	glossySurface.tag = "glossy";
	m_objectMaterials.push_back(glossySurface);

	OBJECT_MATERIAL shinySurface;
	shinySurface.diffuseColor = glm::vec3(0.85f, 0.85f, 0.85f);
	shinySurface.specularColor = glm::vec3(1.0f, 1.0f, 1.0f);  
	shinySurface.shininess = 128.0f;
	shinySurface.tag = "shiny";
	m_objectMaterials.push_back(shinySurface);

	OBJECT_MATERIAL matteSurface;
	matteSurface.diffuseColor = glm::vec3(0.75f, 0.75f, 0.75f);
	matteSurface.specularColor = glm::vec3(0.05f, 0.05f, 0.05f);  
	matteSurface.shininess = 1.0f;
	matteSurface.tag = "matte";
	m_objectMaterials.push_back(matteSurface);

	OBJECT_MATERIAL woodSurface;
	woodSurface.diffuseColor = glm::vec3(0.6f, 0.4f, 0.2f);  
	woodSurface.specularColor = glm::vec3(0.2f, 0.15f, 0.1f);  
	woodSurface.shininess = 16.0f;
	woodSurface.tag = "wood";
	m_objectMaterials.push_back(woodSurface);
}


void SceneManager::LoadSceneTextures() {
	bool bReturn = false;
	bReturn = CreateGLTexture("textures/woodplanks.jpg", "wood");
	bReturn = CreateGLTexture("textures/scratches1.png", "scratch");
	bReturn = CreateGLTexture("textures/wallpaper.png", "wallpaper");
	bReturn = CreateGLTexture("textures/lglogo.png", "logo");
	bReturn = CreateGLTexture("textures/forestsky.jpg", "placemat");
	bReturn = CreateGLTexture("textures/keyboard.jpg", "keyboard");
	BindGLTextures();
}

/***********************************************************
 *  PrepareScene()
 *
 *  This method is used for preparing the 3D scene by loading
 *  the shapes, textures in memory to support the 3D scene 
 *  rendering
 ***********************************************************/
void SceneManager::PrepareScene()
{	
	DefineObjectMaterials();
	SetupSceneLights();
	LoadSceneTextures();
	m_basicMeshes->LoadPlaneMesh();
	m_basicMeshes->LoadPrismMesh();
	m_basicMeshes->LoadCylinderMesh();
	m_basicMeshes->LoadBoxMesh();
	m_basicMeshes->LoadSphereMesh();
	m_basicMeshes->LoadTorusMesh();
}


/***********************************************************
 *  RenderScene()
 *
 *  This method is used for rendering the 3D scene by 
 *  transforming and drawing the basic 3D shapes
 ***********************************************************/
void SceneManager::RenderScene()
{
	RenderTableAndPlacemat();
	RenderMonitor();
	RenderKeyboard();
	RenderMouse();
	RenderController();
	
}
void SceneManager::RenderController() {
	// Variables for the meshes, initialization of rotation variables and position
	glm::vec3 scaleXYZ, positionXYZ;
	float XrotationDegrees = 0.0f, YrotationDegrees = 0.0f, ZrotationDegrees = 0.0f;

	//-------------------Controller------------//
	XrotationDegrees = 3.0f; // Change in X rotation
	SetShaderMaterial("glossy");
	scaleXYZ = glm::vec3(2.9f, .5f, 0.95f);
	positionXYZ = glm::vec3(-7.5, .805, 2.5);
	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	SetShaderColor(0.7f, 0.7f, 0.7f, 1.0f);
	m_basicMeshes->DrawBoxMesh(); // Middle (White)

	scaleXYZ = glm::vec3(2.749f, .3f, 0.745f);
	positionXYZ = glm::vec3(-7.5, .805, 3.0);
	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	SetShaderColor(.1f, .1f, .1f, 1.0f);
	m_basicMeshes->DrawBoxMesh(); // Middle (Black) 

	XrotationDegrees = 10.0f; // Change in X rotation
	YrotationDegrees = -10.0f;
	scaleXYZ = glm::vec3(.5f, .5f, 1.5f);
	positionXYZ = glm::vec3(-9.0, .6, 3.0);
	SetShaderColor(0.7f, 0.7f, 0.7f, 1.0f);
	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	m_basicMeshes->DrawSphereMesh(); // Left Handle (White)

	scaleXYZ = glm::vec3(.5f, .45f, 1.5f);
	positionXYZ = glm::vec3(-8.9, .55, 3.0);
	SetShaderColor(.1f, .1f, .1f, 1.0f);
	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	m_basicMeshes->DrawSphereMesh(); // Left Handle (Black)

	YrotationDegrees = 10.0f;
	scaleXYZ = glm::vec3(.5f, .5f, 1.5f);
	positionXYZ = glm::vec3(-6.0, 0.6, 3.0);
	SetShaderColor(0.7f, 0.7f, 0.7f, 1.0f);
	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	m_basicMeshes->DrawSphereMesh(); // Right Handle (White)

	scaleXYZ = glm::vec3(.5f, .45f, 1.5f);
	positionXYZ = glm::vec3(-6.1, 0.55, 3.0);
	SetShaderColor(.1f, .1f, .1f, 1.0f);
	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	m_basicMeshes->DrawSphereMesh(); // Right Handle (Black)

	// Face Buttons
	XrotationDegrees = 0.0f, YrotationDegrees = 0.0f, ZrotationDegrees = 0.0f; // Default/reinitialize
	scaleXYZ = glm::vec3(.1f, .1f, 0.1f);
	SetShaderColor(.1f, .1f, .1f, 1.0f);

	positionXYZ = glm::vec3(-6.25, 1.1, 2.5);
	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	m_basicMeshes->DrawCylinderMesh(); // Right

	
	positionXYZ = glm::vec3(-6.75, 1.1, 2.5);
	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	m_basicMeshes->DrawCylinderMesh(); // Left

	positionXYZ = glm::vec3(-6.5, 1.1, 2.3);
	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	m_basicMeshes->DrawCylinderMesh(); // Up

	positionXYZ = glm::vec3(-6.5, 1.1, 2.7);
	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	m_basicMeshes->DrawCylinderMesh(); // Down


	// D-Pad
	XrotationDegrees = 0.0f, YrotationDegrees = 0.0f, ZrotationDegrees = 0.0f; // Default/reinitialize
	scaleXYZ = glm::vec3(.2f, .2f, 0.2f);
	SetShaderColor(.1f, .1f, .1f, 1.0f);

	positionXYZ = glm::vec3(-8.5, 1.10, 2.3);
	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	m_basicMeshes->DrawPrismMesh(); // Up

	positionXYZ = glm::vec3(-8.5, 1.10, 2.7);
	YrotationDegrees = 180.0f;
	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	m_basicMeshes->DrawPrismMesh(); // Down

	positionXYZ = glm::vec3(-8.25, 1.10, 2.5);
	YrotationDegrees = -90.0f;
	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	m_basicMeshes->DrawPrismMesh(); // Right

	positionXYZ = glm::vec3(-8.75, 1.10, 2.5);
	YrotationDegrees = 90.0f;
	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	m_basicMeshes->DrawPrismMesh(); // Left

	// Analog Sticks
	XrotationDegrees = 0.0f, YrotationDegrees = 0.0f, ZrotationDegrees = 0.0f; // Default/reinitialize
	scaleXYZ = glm::vec3(0.1f, 0.3f, 0.1f);
	SetShaderColor(0.1f, 0.1f, 0.1f, 1.0f);
	positionXYZ = glm::vec3(-8.0, 0.9, 3.2);
	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	m_basicMeshes->DrawCylinderMesh(); // Left
	positionXYZ = glm::vec3(-7.0, 0.9, 3.2);
	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	m_basicMeshes->DrawCylinderMesh(); // Right


	scaleXYZ = glm::vec3(0.2f, 0.1f, 0.2f);
	positionXYZ = glm::vec3(-8.0, 1.1, 3.2);
	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	m_basicMeshes->DrawCylinderMesh(); // Left Thumbstick

	scaleXYZ = glm::vec3(0.2f, 0.2f, 0.2f);
	XrotationDegrees = 90.0f;
	positionXYZ = glm::vec3(-8.0, 1.175, 3.2);
	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	m_basicMeshes->DrawTorusMesh(); // Left Thumbstick Padding

	XrotationDegrees = 0.0f, YrotationDegrees = 0.0f, ZrotationDegrees = 0.0f; // Default/reinitialize
	
	scaleXYZ = glm::vec3(0.2f, 0.1f, 0.2f);
	positionXYZ = glm::vec3(-7.0, 1.1, 3.2);
	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	m_basicMeshes->DrawCylinderMesh(); // Right Thumbstick

	scaleXYZ = glm::vec3(0.2f, 0.2f, 0.2f);
	XrotationDegrees = 90.0f;
	positionXYZ = glm::vec3(-7.0, 1.175, 3.2);
	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	m_basicMeshes->DrawTorusMesh(); // Left Thumbstick Padding


}
void SceneManager::RenderTableAndPlacemat() {

	// Variables for the meshes, initialization of rotation variables and position
	glm::vec3 scaleXYZ, positionXYZ;
	float XrotationDegrees = 0.0f, YrotationDegrees = 0.0f, ZrotationDegrees = 0.0f;
	
	

	// Table
	scaleXYZ = glm::vec3(20.0f, 1.0f, 10.0f);
	positionXYZ = glm::vec3(0.0f, 0.0f, 0.0f); // Origin
	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	SetShaderTexture("wood");
	SetShaderMaterial("wood");
	SetTextureUVScale(0.75f, 0.75f); // Scale it up
	
	
	m_basicMeshes->DrawPlaneMesh();
	SetShaderTextureOverlay(""); // Erase texture overlay
	SetTextureUVScale(1.0f, 1.0f); // Reset UV Scale for other textures
	/****************************************************************/


	//---------------------------Placemat--------------------//

	scaleXYZ = glm::vec3(10.0f, 1.0f, 3.5f);
	XrotationDegrees = 0.0f; YrotationDegrees = 0.0f; ZrotationDegrees = 0.0f; // Default/reinitialize rotation
	positionXYZ = glm::vec3(0.0, 0.01, 4.0);
	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	SetShaderTexture("placemat");
	m_basicMeshes->DrawPlaneMesh(); // Draw placemat

}
void SceneManager::RenderMonitor() {

	// Variables for the meshes, initialization of rotation variables and position
	glm::vec3 scaleXYZ, positionXYZ;
	float XrotationDegrees = 0.0f, YrotationDegrees = 0.0f, ZrotationDegrees = 0.0f;
	

	//------Left Monitor------//
	scaleXYZ = glm::vec3(1.0f, 5.0f, 1.0f);
	XrotationDegrees = -90.0f;
	YrotationDegrees = -60.0f;
	positionXYZ = glm::vec3(-10.0, 0.51, -5.0);
	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	SetShaderColor(0.05, 0.05, 0.05, 1);
	SetShaderMaterial("matte");
	m_basicMeshes->DrawPrismMesh(); // Draw left leg

	YrotationDegrees = 60.0f; // Change in Y Rotation
	positionXYZ = glm::vec3(-5.0, 0.51, -5.0);
	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	m_basicMeshes->DrawPrismMesh(); // Draw right leg

	scaleXYZ = glm::vec3(.75f, 4.0f, .75f);
	XrotationDegrees = 0.0f; YrotationDegrees = 0.0f; ZrotationDegrees = 0.0f; // Default/reinitialize rotation
	positionXYZ = glm::vec3(-7.5, 0.01, -6.25);
	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	m_basicMeshes->DrawCylinderMesh(); // Draw Cylinder

	scaleXYZ = glm::vec3(.75f, 3.0f, .75f);
	XrotationDegrees = 90.0f;// Change in X Rotation
	positionXYZ = glm::vec3(-7.5, 3.60, -5.25);
	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	m_basicMeshes->DrawBoxMesh(); // Draw connector

	scaleXYZ = glm::vec3(12.0f, 6.0f, .25f);
	XrotationDegrees = -10.0f; // Change in X rotation
	positionXYZ = glm::vec3(-7.5, 5.0, -3.85);
	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	m_basicMeshes->DrawBoxMesh(); // Draw Screen Frame

	scaleXYZ = glm::vec3(5.7f, 1.0f, 2.7f);
	XrotationDegrees = 80.0f;// Change in X rotation
	positionXYZ = glm::vec3(-7.5, 5.0, -3.70);
	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	SetShaderTexture("wallpaper");
	m_basicMeshes->DrawPlaneMesh(); // Draw screen

	scaleXYZ = glm::vec3(.25f, 1.0f, .125f);
	positionXYZ = glm::vec3(-7.5, 2.20, -3.2);
	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	SetShaderTexture("logo");
	m_basicMeshes->DrawPlaneMesh(); // Draw logo

	//---------------------Right Monitor----------------//	
	scaleXYZ = glm::vec3(1.0f, 5.0f, 1.0f);
	XrotationDegrees = -90.0f;
	YrotationDegrees = 60.0f;
	positionXYZ = glm::vec3(10.0, 0.51, -5.0);
	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	SetShaderColor(0.05, 0.05, 0.05, 1);
	SetShaderMaterial("matte");
	m_basicMeshes->DrawPrismMesh(); // Draw right leg

	YrotationDegrees = -60.0f; // Change in Y Rotation
	positionXYZ = glm::vec3(5.0, 0.51, -5.0);
	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	m_basicMeshes->DrawPrismMesh(); // Draw left leg

	scaleXYZ = glm::vec3(.75f, 4.0f, .75f);
	XrotationDegrees = 0.0f; YrotationDegrees = 0.0f; ZrotationDegrees = 0.0f; // Default/reinitialize rotation
	positionXYZ = glm::vec3(7.5, 0.01, -6.25);
	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	m_basicMeshes->DrawCylinderMesh(); // Draw Cylinder

	scaleXYZ = glm::vec3(.75f, 3.0f, .75f);
	XrotationDegrees = 90.0f;// Change in X Rotation
	positionXYZ = glm::vec3(7.5, 3.60, -5.25);
	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	m_basicMeshes->DrawBoxMesh(); // Draw connector

	scaleXYZ = glm::vec3(12.0f, 6.0f, .25f);
	XrotationDegrees = -10.0f; // Change in X rotation
	positionXYZ = glm::vec3(7.5, 5.0, -3.85);
	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	m_basicMeshes->DrawBoxMesh(); // Draw Screen Frame

	scaleXYZ = glm::vec3(5.7f, 1.0f, 2.7f);
	XrotationDegrees = 80.0f;// Change in X rotation
	positionXYZ = glm::vec3(7.5, 5.0, -3.70);
	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	SetShaderTexture("wallpaper");
	m_basicMeshes->DrawPlaneMesh(); // Draw screen

	scaleXYZ = glm::vec3(.25f, 1.0f, .125f);
	positionXYZ = glm::vec3(7.5, 2.20, -3.2);
	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	SetShaderTexture("logo");
	m_basicMeshes->DrawPlaneMesh(); // Draw logo

}
void SceneManager::RenderKeyboard(){
	// Variables for the meshes, initialization of rotation variables and position
	glm::vec3 scaleXYZ, positionXYZ;
	float XrotationDegrees = 0.0f, YrotationDegrees = 0.0f, ZrotationDegrees = 0.0f;
	

	//---------------------------Keyboard--------------------//

	scaleXYZ = glm::vec3(10.0f, 0.25f, 3.0f);
	XrotationDegrees = 0.0f; YrotationDegrees = 0.0f; ZrotationDegrees = 0.0f; // Default/reinitialize rotation
	positionXYZ = glm::vec3(0.0, 0.2, 3.0);
	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	SetShaderColor(0.1, 0.1, 0.1, 1.0);
	m_basicMeshes->DrawBoxMesh(); // Draw keyboard base

	scaleXYZ = glm::vec3(5.0f, 0.125f, 1.5f);
	positionXYZ = glm::vec3(0.0, 0.33, 3.0);
	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	SetShaderTexture("keyboard");
	m_basicMeshes->DrawPlaneMesh(); // Draw keyboard texture
}
void SceneManager::RenderMouse() {
	// Variables for the meshes, initialization of rotation variables and position
	glm::vec3 scaleXYZ, positionXYZ;
	float XrotationDegrees = 0.0f, YrotationDegrees = 0.0f, ZrotationDegrees = 0.0f;

	scaleXYZ = glm::vec3(0.65f, 0.7f, 1.0f);
	positionXYZ = glm::vec3(6.75, 0.1, 3.5);
	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	SetShaderColor(0.2, 0.2, 0.2, 1.0);
	m_basicMeshes->DrawHalfSphereMesh(); // Mouse body

	scaleXYZ = glm::vec3(0.1f, 0.1f, .25f);
	positionXYZ = glm::vec3(6.75, .7, 3.0);
	XrotationDegrees = -25.0f;
	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	SetShaderColor(0.2, 0.2, 0.2, 1.0);
	m_basicMeshes->DrawSphereMesh(); // Scroll wheel

	scaleXYZ = glm::vec3(0.3f, 0.3f, 0.3f);
	positionXYZ = glm::vec3(6.1, 0.4, 3.25);
	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	SetShaderColor(0.0, 0.3, 0.4, 1.0);
	SetShaderMaterial("shiny");
	m_basicMeshes->DrawSphereMesh();  // Trackball

	scaleXYZ = glm::vec3(.4f, .35f, .4f);
	positionXYZ = glm::vec3(6.2, 0.2, 3.25);
	XrotationDegrees = -90.0f;
	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	SetShaderColor(0.2, 0.2, 0.2, 1.0);
	m_basicMeshes->DrawTorusMesh();  // Trackball socket



}


